package hitstd.group.tool.database;

public class DBConfig {
	public DBConfig(){		
	}
	
	public String FilePath(){
	   //YINGBOOK
		 String DBPath="C:\\Users\\user1\\eclipse-workspace\\book\\src\\main\\webapp\\二手書access (1).accdb";
		//String DBPath="C:\\apache-tomcat-10.1.24\\webapps\\ book\\二手書access (1).accdb";
	   return DBPath;		
	}
}