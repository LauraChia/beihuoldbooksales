package hitstd.group.tool.database;

public class DBConfig {
	public DBConfig(){		
	}
	
	public String FilePath(){
	   //YINGBOOK
		 String DBPath="C:\\Users\\user1\\eclipse-workspace\\book\\src\\main\\webapp\\北護二手書販賣系統 (2).accdb";
		//String DBPath="C:\\apache-tomcat-10.1.24\\webapps\\ book\\北護二手書販賣系統.accdb";
	   return DBPath;		
	}
}