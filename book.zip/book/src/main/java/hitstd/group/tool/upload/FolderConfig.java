package hitstd.group.tool.upload;

public class FolderConfig {
	public FolderConfig(){		
	}
	
	public String FilePath(){
	   //YINGBOOK
		 String DBPath="C:\\Users\\user1\\eclipse-workspace\\book\\src\\main\\webapp\\assets\\images\\member";
		//String DBPath="C:\\apache-tomcat-10.1.24\\webapps\\ book\\北護二手書販賣系統.accdb";
	   return DBPath;		
	}
	public String WebsiteRelativeFilePath(){
		   //li's 
		//String Path="assets/images/member/";
		   //Yujia's 
			 String Path="assets/images/member/";
		   return Path;		
		}
}

